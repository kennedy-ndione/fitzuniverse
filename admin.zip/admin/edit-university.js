import {
db
} from "../firebase-config.js";

import {
doc,
getDoc
} from "https://www.gstatic.com/firebasejs/11.10.0/firebase-firestore.js";

import {
updateUniversity
} from "./firebase-admin.js";

import { auth } from "../firebase-config.js";

import { onAuthStateChanged } from "https://www.gstatic.com/firebasejs/11.10.0/firebase-auth.js";

onAuthStateChanged(auth, (user) => {
console.log("Utilisateur connecté :", user);
});



// ===============================
// ID DE L'UNIVERSITÉ
// ===============================

const params = new URLSearchParams(window.location.search);
const universityId = params.get("id");

if (!universityId) {
alert("Aucun identifiant fourni.");
window.location.href = "universities.html";
throw new Error("ID manquant");
}

// ===============================
// CHAMPS DU FORMULAIRE
// ===============================

const universityName = document.getElementById("universityName");
const country = document.getElementById("country");
const city = document.getElementById("city");
const ranking = document.getElementById("ranking");
const language = document.getElementById("language");
const image = document.getElementById("image");
const description = document.getElementById("description");

// ===============================
// CHARGEMENT
// ===============================

async function loadUniversity() {

try {

const ref = doc(db, "universities", universityId);

const snap = await getDoc(ref);

if (!snap.exists()) {

alert("Université introuvable.");

window.location.href = "universities.html";

return;

}

const university = snap.data();

universityName.value = university.university || "";
country.value = university.country || "";
city.value = university.city || "";
ranking.value = university.ranking || "";
language.value = university.language || "";
image.value = university.image || "";
description.value = university.description || "";

} catch (error) {

console.error(error);
alert(error.message);

}

}

loadUniversity();

// ===============================
// ENREGISTRER
// ===============================

const saveButton = document.getElementById("saveUniversityBtn");

saveButton.addEventListener("click", async () => {

try {

await updateUniversity(universityId, {

university: universityName.value.trim(),
country: country.value.trim(),
city: city.value.trim(),
ranking: ranking.value.trim(),
language: language.value.trim(),
image: image.value.trim(),
description: description.value.trim()

});

alert("Université mise à jour avec succès.");

window.location.href = `university.html?id=${universityId}`;

} catch (error) {

console.error(error);

alert(error.message);

}

});
