import {
getUniversities,
getProgram,
addProgram,
updateProgram,
deleteProgram,
updateUniversity
} from "./firebase-admin.js";

/* ==========================================
MODAL PROGRAMME
========================================== */

const programModal = document.getElementById("programModal");

const saveUniversityBtn =
document.getElementById("saveUniversityBtn");

const closeProgramModal =
document.getElementById("closeProgramModal");

const cancelProgramEdit =
document.getElementById("cancelProgramEdit");

const saveProgramEdit =
document.getElementById("saveProgramEdit");

const editLevel =
document.getElementById("editLevel");

const editLanguage =
document.getElementById("editLanguage");

const editDuration =
document.getElementById("editDuration");

const editFunding =
document.getElementById("editFunding");

const editRanking =
document.getElementById("editRanking");

let currentProgramId = null;


/* ==========================================
PARAMÈTRES URL
========================================== */

const params = new URLSearchParams(window.location.search);

const universityId = params.get("id");

/* ==========================================
ÉLÉMENTS HTML
========================================== */

const universityName = document.getElementById("universityName");
const universityLocation = document.getElementById("universityLocation");

const programCount = document.getElementById("programCount");
const scholarshipCount = document.getElementById("scholarshipCount");
const countryName = document.getElementById("countryName");
const rankingValue = document.getElementById("rankingValue");

const infoUniversity = document.getElementById("infoUniversity");
const infoCountry = document.getElementById("infoCountry");
const infoCity = document.getElementById("infoCity");
const infoRanking = document.getElementById("infoRanking");
const infoLanguage = document.getElementById("infoLanguage");
const infoStatus = document.getElementById("infoStatus");

const programsTable = document.getElementById("programsTable");

const statsPrograms = document.getElementById("statsPrograms");
const statsActivePrograms = document.getElementById("statsActivePrograms");
const statsUpdated = document.getElementById("statsUpdated");

/* ==========================================
VARIABLES
========================================== */

let universityPrograms = [];

let university = null;

/* ==========================================
CHARGER L'UNIVERSITÉ
========================================== */

async function loadUniversity() {

try {

const programs = await getUniversities();

universityPrograms = programs.filter(program => {

const docId = program.firestoreId || "";

return docId.startsWith(universityId);

});

if (universityPrograms.length === 0) {

universityName.textContent = "Université introuvable";

universityLocation.textContent =
"Aucun programme n'a été trouvé.";

return;

}

university = universityPrograms[0];

renderUniversity();

renderPrograms();

}

catch (error) {

console.error(error);

universityName.textContent = "Erreur";

universityLocation.textContent =
"Impossible de charger les données.";

}

}

/* ==========================================
AFFICHER LES INFORMATIONS
========================================== */

function renderUniversity() {

universityName.textContent =
university.university || "--";

universityLocation.textContent =
`${university.city || "--"} • ${university.country || "--"}`;

programCount.textContent =
universityPrograms.length;

scholarshipCount.textContent =
universityPrograms.filter(program => program.scholarship).length;

countryName.textContent =
university.country || "--";

rankingValue.textContent =
university.ranking || "--";

infoUniversity.textContent =
university.university || "--";

infoCountry.textContent =
university.country || "--";

infoCity.textContent =
university.city || "--";

infoRanking.textContent =
university.ranking || "--";

infoLanguage.textContent =
university.language || "--";

infoStatus.textContent =
university.isActive ? "Active" : "Inactive";

statsPrograms.textContent =
universityPrograms.length;

statsActivePrograms.textContent =
universityPrograms.filter(program => program.isActive).length;

statsUpdated.textContent =
new Date().toLocaleDateString("fr-FR");

}

/* ==========================================
AFFICHER LES PROGRAMMES
========================================== */

function renderPrograms() {

if (!universityPrograms.length) {

programsTable.innerHTML = `
<tr>
<td colspan="6" class="empty-state">
Aucun programme trouvé.
</td>
</tr>
`;

return;

}

programsTable.innerHTML = "";

universityPrograms.forEach(program => {

const row = document.createElement("tr");

row.innerHTML = `

<td>${program.level || "--"}</td>

<td>${program.funding || "--"}</td>

<td>${program.duration || "--"}</td>

<td>${program.language || "--"}</td>

<td>

<span class="${program.isActive ? "status-active" : "status-inactive"}">

${program.isActive ? "Active" : "Inactive"}

</span>

</td>

<td>

<button
class="table-btn edit-program"
data-id="${program.firestoreId}">

<i class="fas fa-pen"></i>

</button>

<button
class="table-btn delete-program"
data-id="${program.firestoreId}">

<i class="fas fa-trash"></i>

</button>

</td>

`;

programsTable.appendChild(row);

});

}

/* ==========================================
GESTION DES ONGLETS
========================================== */

const tabButtons = document.querySelectorAll(".tab-btn");

const tabPanels = document.querySelectorAll(".tab-panel");

tabButtons.forEach(button => {

button.addEventListener("click", () => {

const tab = button.dataset.tab;

tabButtons.forEach(btn => {

btn.classList.remove("active");

});

tabPanels.forEach(panel => {

panel.classList.remove("active");

});

button.classList.add("active");

const targetPanel = document.getElementById(`${tab}Tab`);

if (targetPanel) {

targetPanel.classList.add("active");

}

});

});

/* ==========================================
INITIALISATION
========================================== */

if (!universityId) {

universityName.textContent = "Université introuvable";

universityLocation.textContent =
"Aucun identifiant n'a été fourni.";

}
else {

loadUniversity();

}

/* ==========================================
ACTIONS SUR LES PROGRAMMES
========================================== */

programsTable.addEventListener("click", (event) => {

const editButton = event.target.closest(".edit-program");

if (editButton) {

const programId = editButton.dataset.id;

openEditProgram(programId);

return;

}

const deleteButton = event.target.closest(".delete-program");

if (deleteButton) {

const programId = deleteButton.dataset.id;

deleteProgramHandler(programId);

}

});

/* ==========================================
AJOUT D'UN PROGRAMME
========================================== */

const addProgramBtn = document.getElementById("addProgramBtn");

if (addProgramBtn) {

addProgramBtn.addEventListener("click", () => {

openCreateProgram();

});

}

/* ==========================================
FONCTIONS (à compléter)
========================================== */

function openCreateProgram() {

console.log("Créer un programme");

}

async function openEditProgram(programId) {

try {

const program = await getProgram(programId);

if (!program) {

alert("Programme introuvable.");

return;

}

currentProgramId = programId;

editLevel.value = program.level || "";

editLanguage.value = program.language || "";

editDuration.value = program.duration || "";

editFunding.value = program.funding || "";

editRanking.value = program.ranking || "";

programModal.style.display = "flex";

}

catch (error) {

console.error(error);

alert("Impossible de charger le programme.");

}

}


async function deleteProgramHandler(programId) {

const confirmation = confirm(
"Voulez-vous vraiment supprimer ce programme ?"
);

if (!confirmation) return;

try {

await deleteProgram(programId);

await loadUniversity();

alert("Programme supprimé avec succès.");

}

catch (error) {

console.error(error);

alert("Erreur lors de la suppression.");

}

}

// ==============================
// MODIFIER L'UNIVERSITÉ
// ==============================

const editUniversityBtn =
document.getElementById("editUniversityBtn");

editUniversityBtn?.addEventListener("click", () => {

window.location.href =
`edit-university.html?id=${universityId}`;

});
