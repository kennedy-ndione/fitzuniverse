// ============================================
// ScholarBridge Admin - Firestore
// ============================================

import { db } from "../firebase-config.js";

import {
collection,
getDocs,
getDoc,
addDoc,
updateDoc,
deleteDoc,
doc,
query,
where
} from "https://www.gstatic.com/firebasejs/11.10.0/firebase-firestore.js";

// ============================================
// UNIVERSITÉS
// ============================================

const universitiesCollection = collection(db, "universities");

// Récupérer toutes les universités
export async function getUniversities() {

const snapshot = await getDocs(universitiesCollection);

return snapshot.docs.map(doc => ({

firestoreId: doc.id,

...doc.data()

}));

}

/* ==========================================
RÉCUPÉRER UN PROGRAMME
========================================== */

export async function getProgram(programId) {

const programRef = doc(db, "universities", programId);

const snapshot = await getDoc(programRef);

if (!snapshot.exists()) {

return null;

}

return {

firestoreId: snapshot.id,

...snapshot.data()

};

}

/* ==========================================
AJOUTER UN PROGRAMME
========================================== */

export async function addProgram(programData) {

const docRef = await addDoc(

universitiesCollection,

programData

);

return docRef.id;

}

/* ==========================================
MODIFIER UN PROGRAMME
========================================== */

export async function updateProgram(programId, programData) {

const programRef = doc(

db,

"universities",

programId

);

await updateDoc(

programRef,

programData

);

}
/* ==========================================
SUPPRIMER UN PROGRAMME
========================================== */

export async function deleteProgram(programId) {

const programRef = doc(

db,

"universities",

programId

);

await deleteDoc(programRef);

}

export async function updateUniversity(firestoreId, data) {

const universityRef = doc(db, "universities", firestoreId);

await updateDoc(universityRef, data);

}
