import { db } from "../firebase-config.js";

import {
collection,
getDocs
} from "https://www.gstatic.com/firebasejs/11.10.0/firebase-firestore.js";

// ===============================
// Éléments HTML
// ===============================

const scholarshipsTable =
document.getElementById("scholarshipsTable");

// ===============================
// Charger les bourses
// ===============================

async function loadScholarships() {

scholarshipsTable.innerHTML = `
<tr>
<td colspan="7" class="empty-state">
Chargement des bourses...
</td>
</tr>
`;

try {

const snapshot =
await getDocs(collection(db, "scholarships"));

if (snapshot.empty) {

scholarshipsTable.innerHTML = `
<tr>
<td colspan="7" class="empty-state">
Aucune bourse trouvée.
</td>
</tr>
`;

return;
}

scholarshipsTable.innerHTML = "";

snapshot.forEach((doc) => {

const scholarship = doc.data();

scholarshipsTable.innerHTML += `
<tr>

<td>${scholarship.title ?? "-"}</td>

<td>${scholarship.country ?? "-"}</td>

<td>${scholarship.level ?? "-"}</td>

<td>${scholarship.funding ?? "-"}</td>

<td>${scholarship.deadline ?? "-"}</td>

<td>
${scholarship.isActive ? "Active" : "Inactive"}
</td>

<td>

<button
class="table-btn view-btn"
data-id="${doc.id}">
<i class="fas fa-eye"></i>
</button>

<button
class="table-btn edit-btn"
data-id="${doc.id}">
<i class="fas fa-pen"></i>
</button>

<button
class="table-btn delete-btn"
data-id="${doc.id}">
<i class="fas fa-trash"></i>
</button>

</td>

</tr>
`;

});

}

catch (error) {

console.error(error);

scholarshipsTable.innerHTML = `
<tr>
<td colspan="7" class="empty-state">
Impossible de charger les bourses.
</td>
</tr>
`;

}

}

loadScholarships();
