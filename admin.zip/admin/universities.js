// ============================================
// ScholarBridge Admin - Universities
// ============================================

import { getUniversities } from "./firebase-admin.js";

const tableBody = document.getElementById("universitiesTable");

async function loadUniversities() {

tableBody.innerHTML = `
<tr>
<td colspan="7">Chargement...</td>
</tr>
`;

try {

const programs = await getUniversities();

// Regrouper par université
const grouped = {};

programs.forEach(program => {

const name = program.university;

if (!grouped[name]) {

grouped[name] = {
university: name,
country: program.country,
city: program.city,
ranking: program.ranking,
image: program.image,
programs: []
};

}

grouped[name].programs.push(program);

});

const universities = Object.values(grouped);

tableBody.innerHTML = "";

universities.forEach(university => {

const row = document.createElement("tr");

row.innerHTML = `
<td>
${university.image ?? "-"}
</td>

<td>
<strong>${university.university}</strong>
</td>

<td>${university.country ?? "-"}</td>

<td>${university.city ?? "-"}</td>

<td>${university.programs.length} programme(s)</td>

<td>${university.ranking ?? "-"}</td>

<td>

<button
class="view-btn"
data-id="${university.programs[0].firestoreId}">
👁
</button>

<button
class="edit-btn"
data-id="${university.programs[0].firestoreId}">
✏️
</button>


</td>
`;

tableBody.appendChild(row);

});

} catch (error) {

console.error(error);

tableBody.innerHTML = `
<tr>
<td colspan="7">
Impossible de charger les universités.
</td>
</tr>
`;

}

}

loadUniversities();

document.addEventListener("click", (event) => {

const button = event.target.closest(".view-btn");

if (!button) return;

const id = button.dataset.id;

window.location.href = `university.html?id=${id}`;

});

document.addEventListener("click", (event) => {

const button = event.target.closest(".edit-btn");

if (!button) return;

const id = button.dataset.id;

window.location.href = `edit-university.html?id=${id}`;

});
