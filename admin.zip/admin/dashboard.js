import { db } from "./firebase-config.js";

import {
collection,
getDocs
} from "https://www.gstatic.com/firebasejs/11.10.0/firebase-firestore.js";

async function chargerStatistiques() {

try {

const universitiesSnapshot = await getDocs(
collection(db, "universities")
);

const scholarshipsSnapshot = await getDocs(
collection(db, "scholarships")
);

const usersSnapshot = await getDocs(
collection(db, "users")
);

document.getElementById("universitiesCount").textContent =
universitiesSnapshot.size;

document.getElementById("scholarshipsCount").textContent =
scholarshipsSnapshot.size;

document.getElementById("usersCount").textContent =
usersSnapshot.size;

} catch (error) {

console.error(error);

alert("Impossible de charger les statistiques.");

}

}

chargerStatistiques();
