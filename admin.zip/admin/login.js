import { auth, db } from "../firebase-config.js";

import {
signInWithEmailAndPassword
} from "https://www.gstatic.com/firebasejs/11.10.0/firebase-auth.js";

import {
doc,
getDoc
} from "https://www.gstatic.com/firebasejs/11.10.0/firebase-firestore.js";

const form = document.getElementById("adminLoginForm");

form.addEventListener("submit", async (e) => {

e.preventDefault();

const email = document.getElementById("email").value.trim();
const password = document.getElementById("password").value;

try {

const credential = await signInWithEmailAndPassword(
auth,
email,
password
);

const uid = credential.user.uid;

const adminRef = doc(db, "admins", uid);

const adminSnap = await getDoc(adminRef);

if (!adminSnap.exists()) {

alert("Vous n'êtes pas autorisé à accéder à l'administration.");

return;

}

window.location.href = "dashboard.html";

}

catch (error) {

console.error(error);

alert(error.message);

}

});
